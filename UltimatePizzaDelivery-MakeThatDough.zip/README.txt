CONTROLS:

WASD - Movement
Space - Fling pepperoni at enemies
Shift - CONSUME

